extends CharacterBody3D

var is_driven := false
var speed := 0.0
var max_speed := 24.0
var acceleration := 18.0
var camera: Camera3D

func _ready() -> void:
	set_physics_process(false)
	var body_mat := StandardMaterial3D.new()
	body_mat.albedo_color = Color("b52d28")
	body_mat.metallic = 0.45
	body_mat.roughness = 0.28
	var body_mesh := BoxMesh.new()
	body_mesh.size = Vector3(2.0, 0.75, 4.0)
	var body := MeshInstance3D.new()
	body.mesh = body_mesh
	body.material_override = body_mat
	body.position.y = 0.65
	add_child(body)
	var cabin_mesh := BoxMesh.new()
	cabin_mesh.size = Vector3(1.55, 0.75, 1.8)
	var cabin := MeshInstance3D.new()
	cabin.mesh = cabin_mesh
	var glass := StandardMaterial3D.new()
	glass.albedo_color = Color("263a48")
	glass.metallic = 0.25
	cabin.material_override = glass
	cabin.position = Vector3(0, 1.35, -0.25)
	add_child(cabin)
	var col := CollisionShape3D.new()
	var shape := BoxShape3D.new()
	shape.size = Vector3(2.0, 1.4, 4.0)
	col.shape = shape
	col.position.y = 0.7
	add_child(col)
	for x in [-1.0, 1.0]:
		for z in [-1.25, 1.25]:
			var wheel := MeshInstance3D.new()
			var cylinder := CylinderMesh.new()
			cylinder.top_radius = 0.38
			cylinder.bottom_radius = 0.38
			cylinder.height = 0.22
			wheel.mesh = cylinder
			var wm := StandardMaterial3D.new()
			wm.albedo_color = Color("17191b")
			wheel.material_override = wm
			wheel.position = Vector3(x, 0.38, z)
			wheel.rotation_degrees.z = 90
			add_child(wheel)
		camera = Camera3D.new()
		camera.position = Vector3(0, 4.5, 9)
		camera.rotation_degrees = Vector3(-20, 0, 0)
		add_child(camera)

func _physics_process(delta: float) -> void:
	if not is_driven:
		return
	var throttle := Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
	var steering := Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
	if abs(throttle) > 0.01:
		speed = move_toward(speed, throttle * max_speed, acceleration * delta)
	else:
		speed = move_toward(speed, 0, acceleration * 0.65 * delta)
	if abs(speed) > 0.5:
		rotation.y -= steering * delta * 1.6 * sign(speed)
	var forward := -global_transform.basis.z
	velocity.x = forward.x * speed
	velocity.z = forward.z * speed
	velocity.y = -0.2
	move_and_slide()
