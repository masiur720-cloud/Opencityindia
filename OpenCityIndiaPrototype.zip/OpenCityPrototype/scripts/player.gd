extends CharacterBody3D

var speed := 7.0
var gravity := 22.0
var camera_pivot: Node3D
var camera: Camera3D

func _ready() -> void:
	var capsule := CapsuleMesh.new()
	capsule.radius = 0.42
	capsule.height = 1.8
	var visual := MeshInstance3D.new()
	visual.mesh = capsule
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color("315f9c")
	visual.material_override = mat
	visual.position.y = 0.9
	add_child(visual)
	var col := CollisionShape3D.new()
	var shape := CapsuleShape3D.new()
	shape.radius = 0.42
	shape.height = 1.8
	col.shape = shape
	col.position.y = 0.9
	add_child(col)
	camera_pivot = Node3D.new()
	camera_pivot.position = Vector3(0, 2.2, 0)
	add_child(camera_pivot)
	camera = Camera3D.new()
	camera.position = Vector3(0, 3.5, 7.5)
	camera.rotation_degrees = Vector3(-18, 0, 0)
	camera.current = true
	camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
	var input := Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var direction := Vector3(input.x, 0, input.y).normalized()
	if direction.length() > 0.05:
		velocity.x = direction.x * speed
		velocity.z = direction.z * speed
		rotation.y = lerp_angle(rotation.y, atan2(-direction.x, -direction.z), delta * 9.0)
	else:
		velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
		velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
	if not is_on_floor():
		velocity.y -= gravity * delta
	else:
		velocity.y = -0.1
	move_and_slide()
