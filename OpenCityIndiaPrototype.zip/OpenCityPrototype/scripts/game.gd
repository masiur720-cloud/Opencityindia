extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const CAR_SCRIPT = preload("res://scripts/car.gd")
var player: CharacterBody3D
var car: CharacterBody3D
var hud: CanvasLayer
var mission_target: Vector3 = Vector3(0, 0, -75)
var mission_done := false
var message_label: Label
var mission_label: Label
var interact_button: Button

func _ready() -> void:
	_make_world()
	_make_city()
	_make_indian_details()
	_make_player()
	_make_car()
	_make_mission_marker()
	_make_hud()
	_update_mission_text()

func _mat(color: Color, roughness := 0.9) -> StandardMaterial3D:
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = roughness
	return m

func _box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, name := "Block") -> MeshInstance3D:
	var mesh := BoxMesh.new()
	mesh.size = size
	var node := MeshInstance3D.new()
	node.name = name
	node.mesh = mesh
	node.material_override = material
	node.position = pos
	parent.add_child(node)
	return node

func _static_box(parent: Node3D, pos: Vector3, size: Vector3, material: Material, name := "Collider") -> void:
	var body := StaticBody3D.new()
	body.position = pos
	body.name = name
	parent.add_child(body)
	_box(body, Vector3.ZERO, size, material, "Visual")
	var shape := CollisionShape3D.new()
	var box_shape := BoxShape3D.new()
	box_shape.size = size
	shape.shape = box_shape
	body.add_child(shape)

func _make_world() -> void:
	var world_env := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	env.sky = Sky.new()
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color(0.72, 0.78, 0.88)
	env.ambient_light_energy = 0.7
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world_env.environment = env
	add_child(world_env)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_energy = 1.25
	sun.shadow_enabled = true
	add_child(sun)
	_static_box(self, Vector3(0, -0.6, 0), Vector3(230, 1, 230), _mat(Color("30383d")), "Ground")
	# Main asphalt roads and sidewalks
	_box(self, Vector3(0, -0.04, 0), Vector3(18, 0.12, 220), _mat(Color("25292d")), "MainRoad")
	_box(self, Vector3(0, 0.03, 0), Vector3(0.18, 0.02, 220), _mat(Color("e8d9a8")), "RoadLine")
	_box(self, Vector3(0, 0.0, 0), Vector3(220, 0.12, 18), _mat(Color("25292d")), "CrossRoad")
	_box(self, Vector3(0, 0.08, 0), Vector3(220, 0.02, 0.18), _mat(Color("e8d9a8")), "CrossLine")
	for side in [-1, 1]:
		_box(self, Vector3(side * 10.5, 0.12, 0), Vector3(3, 0.25, 220), _mat(Color("888b8d")), "Sidewalk")
		_box(self, Vector3(0, 0.12, side * 10.5), Vector3(220, 0.25, 3), _mat(Color("888b8d")), "Sidewalk")

func _make_city() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 2048
	var colors := [Color("b7a89a"), Color("9caeb5"), Color("c5c0b5"), Color("8d9998"), Color("b5b8ad"), Color("a7a0a0")]
	for x in range(-4, 5):
		for z in range(-4, 5):
			if abs(x) <= 1 and abs(z) <= 1:
				continue
			var px := float(x) * 29.0 + rng.randf_range(-2, 2)
			var pz := float(z) * 29.0 + rng.randf_range(-2, 2)
			var w := rng.randf_range(12, 19)
			var d := rng.randf_range(12, 19)
			var h := rng.randf_range(9, 32)
			var building := StaticBody3D.new()
			building.position = Vector3(px, h / 2.0, pz)
			building.name = "Building"
			add_child(building)
			var mat := _mat(colors[rng.randi_range(0, colors.size() - 1)])
			_box(building, Vector3.ZERO, Vector3(w, h, d), mat, "Facade")
			var shape := CollisionShape3D.new()
			var bs := BoxShape3D.new()
			bs.size = Vector3(w, h, d)
			shape.shape = bs
			building.add_child(shape)
			# Rooftop cap gives the skyline some variation.
			_box(building, Vector3(0, h / 2.0 + 0.25, 0), Vector3(w * 0.72, 0.5, d * 0.72), _mat(Color("666e72")), "Roof")
	# Trees along the sidewalks
	for z in range(-9, 10, 2):
		for side in [-1, 1]:
			var trunk := _box(self, Vector3(side * 12.7, 1.0, z * 10.0), Vector3(0.45, 2, 0.45), _mat(Color("594333")), "TreeTrunk")
			var crown := _box(self, trunk.position + Vector3(0, 2.0, 0), Vector3(2.5, 2.5, 2.5), _mat(Color("47734c")), "TreeCrown")


func _make_indian_details() -> void:
	# Busy Indian market frontage along the central roads.
	var shop_colors := [Color("d96b32"), Color("e2b43d"), Color("3c8b79"), Color("b94b59"), Color("4779a8")]
	var sign_colors := [Color("fff0c2"), Color("f8e7d1"), Color("e8f2dc")]
	for side in [-1, 1]:
		for i in range(5):
			var z := -34.0 + float(i) * 16.0
			var shop_mat := _mat(shop_colors[(i + (1 if side > 0 else 0)) % shop_colors.size()])
			_box(self, Vector3(side * 13.3, 1.8, z), Vector3(1.1, 3.6, 8.0), shop_mat, "MarketShop")
			_box(self, Vector3(side * 12.68, 2.45, z), Vector3(0.12, 0.75, 6.6), _mat(Color("f3c45b")), "ShopAwning")
			var board := Label3D.new()
			board.text = ["CHAI • SNACKS", "BAZAAR", "MOBILE SHOP", "SWEETS", "GENERAL STORE"][i]
			board.font_size = 32
			board.pixel_size = 0.008
			board.modulate = sign_colors[i % sign_colors.size()]
			board.position = Vector3(side * 12.62, 3.35, z)
			board.rotation_degrees.y = 90 if side > 0 else -90
			add_child(board)
	# Street-food carts: counter, canopy and wheels.
	for z in [-19.0, 19.0]:
		var cart := Node3D.new()
		cart.position = Vector3(-7.0, 0.0, z)
		add_child(cart)
		_box(cart, Vector3.ZERO, Vector3(2.2, 1.0, 1.25), _mat(Color("a65c32")), "FoodCart")
		_box(cart, Vector3(0, 1.0, 0), Vector3(2.5, 0.12, 1.5), _mat(Color("e4a83d")), "CartCanopy")
		for x in [-0.8, 0.8]:
			var wheel := MeshInstance3D.new()
			var cyl := CylinderMesh.new()
			cyl.top_radius = 0.24
			cyl.bottom_radius = 0.24
			cyl.height = 0.12
			wheel.mesh = cyl
			wheel.material_override = _mat(Color("242424"))
			wheel.position = Vector3(x, 0.25, 0.68)
			wheel.rotation_degrees.z = 90
			cart.add_child(wheel)
	# A small Indian temple landmark in the market district.
	var temple := Node3D.new()
	temple.position = Vector3(31, 0, -31)
	add_child(temple)
	_box(temple, Vector3(0, 2.0, 0), Vector3(12, 4, 10), _mat(Color("d9a66b")), "TempleHall")
	_box(temple, Vector3(0, 4.25, 0), Vector3(8, 0.5, 7), _mat(Color("b94d32")), "TempleRoof")
	var spire := MeshInstance3D.new()
	var cone := CylinderMesh.new()
	cone.top_radius = 0.15
	cone.bottom_radius = 2.0
	cone.height = 5.0
	spire.mesh = cone
	spire.material_override = _mat(Color("c65a35"))
	spire.position = Vector3(0, 6.8, 0)
	temple.add_child(spire)
	var temple_sign := Label3D.new()
	temple_sign.text = "MANDIR"
	temple_sign.font_size = 42
	temple_sign.position = Vector3(0, 3.0, 5.1)
	temple_sign.rotation_degrees.y = 180
	temple.add_child(temple_sign)
	# Parked auto-rickshaw prop near the market (visual landmark).
	var rickshaw := Node3D.new()
	rickshaw.position = Vector3(-5.5, 0, -8.0)
	rickshaw.rotation_degrees.y = 90
	add_child(rickshaw)
	_box(rickshaw, Vector3(0, 0.95, 0), Vector3(1.65, 1.35, 2.5), _mat(Color("e5bd27")), "AutoBody")
	_box(rickshaw, Vector3(0, 1.85, -0.1), Vector3(1.55, 0.65, 1.7), _mat(Color("252b2c")), "AutoRoof")
	_box(rickshaw, Vector3(0, 1.05, -0.95), Vector3(1.3, 0.75, 0.08), _mat(Color("79aeb9")), "AutoWindscreen")
	for x in [-0.75, 0.75]:
		var wheel := MeshInstance3D.new()
		var wheel_mesh := CylinderMesh.new()
		wheel_mesh.top_radius = 0.34
		wheel_mesh.bottom_radius = 0.34
		wheel_mesh.height = 0.18
		wheel.mesh = wheel_mesh
		wheel.material_override = _mat(Color("171717"))
		wheel.position = Vector3(x, 0.35, 0.65)
		wheel.rotation_degrees.z = 90
		rickshaw.add_child(wheel)
	# Simple roadside poles and warm signboards.
	for z in range(-40, 41, 20):
		for side in [-1, 1]:
			_box(self, Vector3(side * 11.8, 2.4, float(z)), Vector3(0.16, 4.8, 0.16), _mat(Color("55575a")), "StreetLightPole")
			_box(self, Vector3(side * 11.8, 4.8, float(z)), Vector3(1.2, 0.12, 0.12), _mat(Color("e8d9a8")), "StreetLightArm")

func _make_player() -> void:
	player = CharacterBody3D.new()
	player.name = "Player"
	player.set_script(PLAYER_SCRIPT)
	player.position = Vector3(3, 1.1, 7)
	add_child(player)

func _make_car() -> void:
	car = CharacterBody3D.new()
	car.name = "SportsCar"
	car.set_script(CAR_SCRIPT)
	car.position = Vector3(3, 0.8, 1)
	add_child(car)

func _make_mission_marker() -> void:
	var marker_mat := _mat(Color("ffd83d"), 0.35)
	var marker := MeshInstance3D.new()
	var ring := CylinderMesh.new()
	ring.top_radius = 2.2
	ring.bottom_radius = 2.2
	ring.height = 0.18
	marker.mesh = ring
	marker.material_override = marker_mat
	marker.position = mission_target + Vector3(0, 0.25, 0)
	add_child(marker)
	var beacon := MeshInstance3D.new()
	var pillar := CylinderMesh.new()
	pillar.top_radius = 0.18
	pillar.bottom_radius = 0.18
	pillar.height = 5.0
	beacon.mesh = pillar
	beacon.material_override = marker_mat
	beacon.position = mission_target + Vector3(0, 2.8, 0)
	add_child(beacon)

func _make_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	var panel := PanelContainer.new()
	panel.position = Vector2(18, 18)
	panel.custom_minimum_size = Vector2(310, 90)
	hud.add_child(panel)
	var vbox := VBoxContainer.new()
	panel.add_child(vbox)
	var title := Label.new()
	title.text = "OPEN CITY INDIA  •  OFFLINE"
	title.add_theme_font_size_override("font_size", 20)
	vbox.add_child(title)
	mission_label = Label.new()
	mission_label.text = "MISSION: Reach the yellow marker"
	vbox.add_child(mission_label)
	message_label = Label.new()
	message_label.text = "Explore the bazaar • E: enter / exit car"
	message_label.position = Vector2(20, 118)
	message_label.add_theme_font_size_override("font_size", 16)
	hud.add_child(message_label)
	var controls := HBoxContainer.new()
	controls.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_RIGHT)
	controls.position = Vector2(-270, -82)
	controls.size = Vector2(250, 58)
	hud.add_child(controls)
	interact_button = Button.new()
	interact_button.text = "ENTER / EXIT"
	interact_button.custom_minimum_size = Vector2(135, 54)
	interact_button.pressed.connect(_interact)
	controls.add_child(interact_button)
	# Large hold buttons work with touchscreens as well as mouse input.
	var pad := HBoxContainer.new()
	pad.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	pad.position = Vector2(18, -86)
	pad.size = Vector2(270, 64)
	hud.add_child(pad)
	_add_hold_button(pad, "◀", "move_left")
	_add_hold_button(pad, "▲", "move_forward")
	_add_hold_button(pad, "▼", "move_back")
	_add_hold_button(pad, "▶", "move_right")
	var hint := Label.new()
	hint.text = "Touch controls: arrows + ENTER / EXIT\nKeyboard: WASD / arrows + E"
	hint.position = Vector2(18, -74)
	hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_LEFT)
	hud.add_child(hint)

func _process(_delta: float) -> void:
	if not mission_done:
		var actor_pos: Vector3 = player.global_position if is_instance_valid(player) else car.global_position
		if actor_pos.distance_to(mission_target) < 5.0:
			mission_done = true
			mission_label.text = "MISSION COMPLETE!  +$500"
			message_label.text = "Nice driving! Explore the city or restart to play again."

func _add_hold_button(parent: Control, label_text: String, action: String) -> void:
	var b := Button.new()
	b.text = label_text
	b.custom_minimum_size = Vector2(60, 58)
	b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	b.button_down.connect(func(): Input.action_press(action))
	b.button_up.connect(func(): Input.action_release(action))
	parent.add_child(b)

func _interact() -> void:
	if player == null or car == null:
		return
	if player.visible:
		if player.global_position.distance_to(car.global_position) < 4.5:
			player.visible = false
			player.set_physics_process(false)
			car.set_physics_process(true)
			car.is_driven = true
			player.camera.current = false
			car.camera.current = true
			message_label.text = "You are driving. Press E / ENTER-EXIT to leave the car."
		else:
			message_label.text = "Move closer to the car to enter it."
	else:
		player.global_position = car.global_position + Vector3(2.5, 0.2, 0)
		player.visible = true
		player.set_physics_process(true)
		car.is_driven = false
		car.camera.current = false
		player.camera.current = true
		car.set_physics_process(false)
		message_label.text = "You are on foot. Find the yellow mission marker."

func _update_mission_text() -> void:
	mission_label.text = "MISSION: Reach the yellow marker (+$500)"
