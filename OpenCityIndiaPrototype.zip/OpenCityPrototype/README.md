# Open City India — Android 3D Prototype

An offline, single-player, third-person city sandbox prototype made for Godot 4.3+.

## Included in this prototype
- Procedurally generated city block with roads, sidewalks, buildings and trees
- Indian market frontage with colourful shop signs and awnings
- Street-food carts, a parked auto-rickshaw, a small mandir landmark and roadside poles
- Third-person character movement
- Drivable sports car with enter/exit interaction
- Simple reach-the-marker mission
- Offline play; no accounts or network connection required
- Basic HUD and an on-screen enter/exit button

## Controls
- WASD or arrow keys: walk / steer
- E: enter or exit the car
- W / Up: accelerate; S / Down: reverse or brake
- A / Left and D / Right: steer
- On-screen button: enter / exit car

## Open and run on a computer
1. Install Godot Engine 4.3 or newer (standard build).
2. Open Godot Project Manager and choose **Import**.
3. Select this folder's `project.godot` file.
4. Open the project and press F6 or F5.

## Export an Android APK
1. Install Godot 4.3+ and its matching export templates: **Editor → Manage Export Templates**.
2. Install Android Studio, Android SDK Platform Tools, Android SDK Build-Tools and the Android command-line tools.
3. In Godot, open **Editor → Editor Settings → Export → Android** and set the Android SDK path and Java SDK path as shown in the Godot Android export documentation.
4. Open **Project → Export**, add an **Android** preset, set a unique package identifier (for example `com.example.opencity`), and configure the app name and orientation.
5. Export to `OpenCity.apk`. For a local test install, enable installation from your chosen file manager and install the APK.

## Important scope note
This is a starter prototype, not a finished GTA-scale game. The city is built from simple procedural 3D geometry. It does not yet include pedestrians, police, combat, traffic AI, save games, sound, or a full mission campaign. Those can be added in later development passes.

## Android touch controls
This starter includes touch-friendly directional buttons and an enter/exit button. These are prototype controls; test and refine their layout on the target Android screen before release.
